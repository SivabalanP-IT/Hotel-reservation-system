package com.util;
//import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
public class ApplicationUtil {
	 
	 public static List<String> extractToList(String record) {
		// TODO Auto-generated method stub
		 List<String> list=new ArrayList<>();
		 if(record!=null) {
			 String[] tokens = record.split(":");
	            for (String token : tokens) {
	                list.add(token.trim());
	            }
		 }
//		 System.out.println(list);
		 return list;
		 
	 }
	 
	 public static List<String> extractBookingDetails(String details){
		 
		 List<String> list=new ArrayList<>();
		 if(details!=null) {
			 String[] tokens = details.split(":");
	            for (String token : tokens) {
	                list.add(token.trim());
	            }
		 }
//		 System.out.println(list);
		 return list;
	        
	 }
}
