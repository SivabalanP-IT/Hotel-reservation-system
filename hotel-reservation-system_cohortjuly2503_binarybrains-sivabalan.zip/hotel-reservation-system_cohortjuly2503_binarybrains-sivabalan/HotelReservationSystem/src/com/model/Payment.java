package com.model;
import java.util.*;

public class Payment {
	
	private String paymentId;
	private String bookingId;
	private String residentName;
	private String floorNumber;
	private String roomNumber;
	private Date checkInDate;
	private Date checkOutDate;
	private Date paymentDate;
	private String paymentMethod;
	private double billAmount;
	public Payment(String paymentId, String bookingId, String residentName, String floorNumber, String roomNumber,
			Date checkInDate, Date checkOutDate, Date paymentDate, String paymentMethod, double billAmount) {
		super();
		this.paymentId = paymentId;
		this.bookingId = bookingId;
		this.residentName = residentName;
		this.floorNumber = floorNumber;
		this.roomNumber = roomNumber;
		this.checkInDate = checkInDate;
		this.checkOutDate = checkOutDate;
		this.paymentDate = paymentDate;
		this.paymentMethod = paymentMethod;
		this.billAmount = billAmount;
	}
	public Payment() {
		// TODO Auto-generated constructor stub
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getBookingId() {
		return bookingId;
	}
	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}
	public String getResidentName() {
		return residentName;
	}
	public void setResidentName(String residentName) {
		this.residentName = residentName;
	}
	public String getFloorNumber() {
		return floorNumber;
	}
	public void setFloorNumber(String floorNumber) {
		this.floorNumber = floorNumber;
	}
	public String getRoomNumber() {
		return roomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	public Date getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(Date checkInDate) {
		this.checkInDate = checkInDate;
	}
	public Date getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(Date checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public Date getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public double getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(double billAmount) {
		this.billAmount = billAmount;
	}
	
//	 public double calculateBillAmount(List<Booking> booking) {
//		    String floorNo=null;
//		    int childAbove5=0;
//		    int childAbove12=0;
//		    int adults=0;
//		    int nights=0;
//		    String ac=null;
//		    
//	    	for(Booking b:booking) {
//	    	floorNo=b.getFloorNumber();
//	    	childAbove5=b.getNumberOfChildrenAbove5();
//	    	childAbove12=b.getNumberOfChildrenAbove12();
//	    	adults=b.getNumberOfAdults();
//	    	nights=b.getDurationOfStay();
//	    	ac = b.getAcAccess();
//	    	}
//	    	
//	    	double roomRent=0;
//	    	switch(floorNo) {
//	    	
//	    	case "F1": 
//	    		roomRent=1500;
//	    		break;
//	    	case "F2":
//	    		roomRent=2000;
//	    		break;
//	    	case "F3":
//	    		roomRent=2500;
//	    		break;
//	    	case "F4":
//	    		roomRent=4000;
//	    		break;
//	    	default:
//	    		System.out.println("Invalid floor number!");
//	    		
//	    	}
//	    	
//	    	
//	    	
//	    	double adultCharge = adults * roomRent;
//	        double childAbove12Charge = childAbove12 * (0.4 * roomRent);
//	        double child6to12Charge = childAbove5 * 500;
//	        double childUnder5Charge = 0;
//	        double totalPeopleCharge = adultCharge + childAbove12Charge + child6to12Charge + childUnder5Charge;
//	        
//	        double acCharge=0;
//	        
//	        if(ac.equalsIgnoreCase("yes"))
//	        	acCharge=750;
//	        else if(ac.equalsIgnoreCase("no"))
//	        	acCharge=0;
//	        
//	        double totalRoomCost = (totalPeopleCharge + acCharge) * nights;
//	        
//	        double foodCharge = 0;
//	        double discount = 0;
////	        String packageInfo = "";
//	        
//	        if(floorNo.equalsIgnoreCase("F4")) {
////	        	packageInfo = "Package 3: Complimentary breakfast, dinner, pool, and gym";
//	            foodCharge = 0;
//	        }
//	        
//	        else if (nights > 3) {
////	            packageInfo = "Package 1: Complimentary breakfast and 10% discount";
//	            discount = 0.10;
//	        } 
//	        
//	        else {
////	            packageInfo = "Package 2: 10% of room rent per day for breakfast and dinner";
//	            foodCharge = 0.10 * roomRent * nights;
//	        }
//
//	        double subtotal = totalRoomCost + foodCharge;
//	        double discountAmount = subtotal * discount;
//	        double finalBill = subtotal - discountAmount;
//	        
//	        return finalBill;
//	        }


}
