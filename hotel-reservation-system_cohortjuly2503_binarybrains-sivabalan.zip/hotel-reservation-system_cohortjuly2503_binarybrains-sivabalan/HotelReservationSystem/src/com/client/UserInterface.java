package com.client;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import com.management.PaymentManagement;
import com.model.*;
import com.service.*;

public class UserInterface {

    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);

            RIResidentService ri = new RIResidentService();
            NRIResidentService nri = new NRIResidentService();
            BookingService bs = new BookingService();
            RoomService rs = new RoomService();
            ManagerService ms = new ManagerService();
            PaymentService ps=new PaymentService();
            Payment p=new Payment();
            PaymentManagement paymentManagement=new   PaymentManagement();
            System.out.println("====================================================");
            System.out.println("---------Welcome to Sweet Homes Regency------------");
            System.out.println("====================================================");
          
            while (true) {
//            	System.out.println("------------LOGIN-------------");
            	System.out.println("1.Customer Login\n2.Manager Login\n3.Exit");
                System.out.print("Enter your choice: ");
                int choice=sc.nextInt();
                
//                    System.out.println("Invalid input! Please enter a number.");
//                    sc.next();
//                }
//            
//                sc.nextLine(); // clear newline

                switch (choice) {

                    case 1: // Customer Login
                    	System.out.println("----------Customer Login----------");
                        System.out.println("1.Book Room\n2.Manage Booking\n3.Cancel Booking\n4.View Booking\n5.Manage ResidentDetails\n6.Delete Registration\n7.View payment Details");
                        int chcust = sc.nextInt();
                        sc.nextLine();

                        if (chcust == 1) {
                        	System.out.println("----------Book Room----------");
                            System.out.println("Are you an Existing customer (Yes/No)?");
                            String cust = sc.next();

                            if (cust.equalsIgnoreCase("yes")) {
                                System.out.println("Please Enter your Resident Id:");
                                String residentId = sc.next();

                                if (residentId.startsWith("RI")) {
                                    List<RIResident> exists = ri.retreiveRIResidentDetailsForBooking(residentId);
                                    String riId=null;
                                    if (exists != null) {
                                        for(RIResident r:exists) {
                                        	riId = r.getResidentId();
                                        }
                                    	
//                                        String name=exists.getResidentName()
                                        System.out.println("Enter the Details : (residentName:DurationOfStay:NoOfAdults:NoOfChildAbove12:NoOfChildAbove5)");
                                        String booking = sc.next();

                                        System.out.println("Please select your preferred package: Premium / Gold / Silver");
                                        String pack = sc.next();

                                        String floor = null, poolAccess = null, gymAccess = null, ac = null;

                                        if (pack.equalsIgnoreCase("Premium")) {
                                            floor = "F4";
                                            poolAccess = "yes";
                                            gymAccess = "yes";
                                            System.out.println("Do you Want a Room with Air Conditioner (yes/no)?");
                                            ac = sc.next();
                                        } else if (pack.equalsIgnoreCase("Gold") || pack.equalsIgnoreCase("Silver")) {
                                            System.out.println("Enter the floor number you want:");
                                            floor = sc.next();
                                            poolAccess = "no";
                                            gymAccess = "no";
                                            System.out.println("Do you Want a Room with Air Conditioner (yes/no)?");
                                            ac = sc.next();
                                        }

                                        List<Room> availableRooms = ms.viewAvailableRoomForParticularFloorNumber(floor);
                                        if (!availableRooms.isEmpty()) {
                                            String roomNo = availableRooms.get(0).getRoomNumber();
                                            List<Booking> bookingObj = bs.buildBooking(riId, booking, floor, roomNo, poolAccess, gymAccess, ac, pack);
                                            // TODO: Save booking here
                                            boolean valid=bs.addBookingList(bookingObj);
                                            System.out.println("-----------Generate payment record-----------");
//                                            double billAmount=PaymentService.calculateBillAmount(bookingObj);
                                            System.out.println("Enter Payment Method (Cash/Card/UPI)");
                                            String paymentMethod = sc.next();
                                            List<Payment> payment =ps.buildPaymentList(bookingObj, paymentMethod);
                                            
                                            if(!payment.isEmpty())
                                            	System.out.println("Your payment successfully completed");
                                            else
                                            	System.out.println("Your payment not successfully completed");
                                            
                                            if(valid)
                                            	System.out.println("Booked successfully");
                                            else
                                            	System.out.println("Booked not successfully");
                                        } else {
                                            System.out.println("No available rooms on the selected floor.");
                                        }

                                    } else {
                                        System.out.println("Resident ID not found.");
                                    }
                                }
                                
                                if (residentId.startsWith("NRI")) {
                                    List<NRIResident> exists = nri.retreiveNRIResidentDetailsForBooking(residentId);
                                     String nriId=null;
                                    if (exists != null) {
                                    	for(NRIResident nr:exists) {
                                             nriId = nr.getResidentId();
                                    	}

                                        System.out.println("Enter the details : (residentName:DurationOfStay:NoOfAdults:NoOfChildAbove12:NoOfChildAbove5)");
                                        String booking = sc.next();

                                        System.out.println("Please select your preferred package: Premium / Gold / Silver");
                                        String pack = sc.next();

                                        String floor = null, poolAccess = null, gymAccess = null, ac = null;

                                        if (pack.equalsIgnoreCase("Premium")) {
                                            floor = "F4";
                                            poolAccess = "yes";
                                            gymAccess = "yes";
                                            System.out.println("Do you Want a Room with Air Conditioner (yes/no)?");
                                            ac = sc.next();
                                        } else if (pack.equalsIgnoreCase("Gold") || pack.equalsIgnoreCase("Silver")) {
                                            System.out.println("Enter the floor number you want:");
                                            floor = sc.next();
                                            poolAccess = "no";
                                            gymAccess = "no";
                                            System.out.println("Do you Want a Room with Air Conditioner (yes/no)?");
                                            ac = sc.next();
                                        }

                                        List<Room> availableRooms = ms.viewAvailableRoomForParticularFloorNumber(floor);
                                        if (!availableRooms.isEmpty()) {
                                            String roomNo = availableRooms.get(0).getRoomNumber();
                                            List<Booking> bookingObj = bs.buildBooking(nriId, booking, floor, roomNo, poolAccess, gymAccess, ac, pack);
                                            bs.addBookingList(bookingObj);
                                            
                                            System.out.println("----------Generate payment record------------");
                                            double billAmount=PaymentService.calculateBillAmount(bookingObj);
                                            System.out.println("Enter Payment Method (Cash/Card/UPI)");
                                            String paymentMethod = sc.next();
                                            List<Payment> payment =ps.buildPaymentList(bookingObj, paymentMethod);
                                            
                                            if(!payment.isEmpty())
                                            	System.out.println("Your payment successfully completed");
                                            else
                                            	System.out.println("Your payment not successfully completed");
                                            String roomNum=null;
                                            
                                            for(Booking b:bookingObj) {
                                            	roomNum=b.getRoomNumber();
                                            }
                                            
                                            boolean update=rs.updateOccupiedStatus(roomNum);
                                            
                                            if(update) {
                                            	System.out.println("Room status upated successfully");
                                            }
                                            else
                                            	System.out.println("Room status not updated");
                                            	
                                            
                                        } else {
                                            System.out.println("No available rooms on the selected floor.");
                                        }

                                    } else {
                                        System.out.println("Resident ID not found.");
                                    }
                                }
                            }
                                  else if (cust.equalsIgnoreCase("no")) {
                                	  System.out.println("Please Register First");
                                	
                                    System.out.println("Enter the type (RI/NRI):");
                                    String type = sc.next();

                                    if (type.equalsIgnoreCase("RI")) {
                                        sc.nextLine();
                                        System.out.println("Enter the Details : (ResidentName:Age:Gender:PhoneNumber:Email:Address:NoOfAdults:NoOfChildAbove12:NoOfChildAbove5:DurationOfStay:ResidentType:IdProof)");
                                        String input = sc.nextLine();
                                        int num = ri.addRIResidentList(input);
//                                        System.out.println(num + " record(s) inserted successfully.");
//                                        System.out.println("This is Yours ResidentID "+RIResidentService.generateId());

                                    } else if (type.equalsIgnoreCase("NRI")) {
                                        sc.nextLine();
                                        System.out.println("Enter the Details : (ResidentName:Age:Gender:PhoneNumber:Email:Address:NoOfAdults:NoOfChildAbove12:NoOfChildAbove5:DurationOfStay:ResidentType:PassportNo:PassportType:Nationality:PurposeForVisit)");
                                        String input1 = sc.nextLine();
                                        int num1 = nri.addNRIResidentList(input1);
//                                        if (num1 > 0) {
                                            
//                                        }
//                                        else
//                                            System.out.println("Record not inserted.");
                                    }
                                    
                                   
                                }
                        } 
                        
                        else if(chcust == 2) {
                        	System.out.println("----------Manage Booking----------");
                        	System.out.println("Enter what you want to update?");
                        	System.out.println("1.updateCheckInAndCheckOutUsingBookingId\n2.updatePackageUsingBookingId\n3.updateExtraAccessUsingBookingId");
                        	int opt = sc.nextInt();
                        	
                        	switch(opt) {
                        	case 1:
                        		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");

                        		try {
                        		    System.out.println("Enter the bookingId to update :");
                        		    // Use sc.nextLine() to read the full ID and clear the buffer
                        		    // You must ensure previous sc.next() calls are handled
                        		    // If you start with sc.nextLine() you must use it consistently.
                        		    // For this example, let's assume 'sc.next()' for ID is okay, 
                        		    // but we need to clear the buffer.
                        		    String id = sc.next();
                        		    
                        		    // Consume the leftover newline after sc.next()
                        		    sc.nextLine(); 

                        		    // --- Check-in Date Input ---
                        		    System.out.print("Enter check-in date (dd-MM-yyyy): ");
                        		    // Use sc.nextLine() to ensure we capture the entire input line
                        		    String input1 = sc.nextLine().trim(); 
                        		    
                        		    // Parse the string directly into a LocalDate
                        		    LocalDate checkInDate = LocalDate.parse(input1, format);

                        		    // --- Check-out Date Input ---
                        		    System.out.print("Enter check-out date (dd-MM-yyyy): ");
                        		    String input2 = sc.nextLine().trim(); 

                        		    // Parse the string directly into a LocalDate
                        		    LocalDate checkOutDate = LocalDate.parse(input2, format);
                        		    
                        		    // --- Conversion to java.sql.Date ---
                        		    // Use java.sql.Date.valueOf() for correct conversion from LocalDate
                        		    java.sql.Date checkInSQL = java.sql.Date.valueOf(checkInDate);
                        		    java.sql.Date checkOutSQL = java.sql.Date.valueOf(checkOutDate);

                        		    System.out.println(id + " " + checkInSQL + " " + checkOutSQL);

                        		    // --- Date Comparison ---
                        		    // Use the modern API's built-in comparison methods (isBefore, isEqual, isAfter)
                        		    if (checkOutDate.isBefore(checkInDate)) { 
                        		        System.out.println("Error: Check-out date cannot be before Check-in date!");
                        		    } else {
                        		        // This handles check-out date is on or after check-in date
                        		        bs.updateCheckInAndCheckOutUsingBookingId(id, checkInSQL, checkOutSQL);
                        		    }

                        		// Catch the correct exception for date parsing errors
                        		} catch (DateTimeParseException e) { 
                        		    System.out.println("Invalid Date Format! Please enter correct format (dd-MM-yyyy).");
                        		    // e.printStackTrace(); // Optional: uncomment for detailed debugging
                        		} 
                        		// Catch other potential exceptions like database errors, etc.
                        		catch (Exception e) {
                        		    System.out.println("An unexpected error occurred: " + e.getMessage());
          }
                        		
                        		break;
                        	case 2:
                        		System.out.println("Enter the bookingId to update");
                        		String id = sc.next();
                        		System.out.println("Enter the package you want to update");
                        		String pack = sc.next();
                        		bs.updatePackageUsingBookingId(id, pack);
                        		break;
                        	case 3:
                        		System.out.println("Enter the bookingId to update");
                        		String bookid = sc.next();
                        		System.out.println("Enter AC access to update");
                        		String ac = sc.next();
                        		System.out.println("Enter Pool access to update");
                        		String pool = sc.next();
                        	    System.out.println("Enter Gym access to update");
                        	    String gym = sc.next();
                        	    bs.updateExtraAccessUsingBookingId(bookid, ac, pool, gym);
                        	    break;
                        	    
                        	default:
                        		System.out.println("Invalid option");
                        	}
                        }


                        else if(chcust == 3) {
                        	System.out.println("----------Cancel Booking----------");
                        	System.out.println("Enter the bookingId for cancel");
                        	String id = sc.next();
                        	bs.cancelBookingFromDB(id);
                        }

                        else if(chcust == 4) {
                        	System.out.println("----------View Booking----------");
                        	System.out.println("Enter the bookingId to view details");
                        	String id = sc.next();
                        	List<Booking> details = bs.viewBookingDetails(id);
                        	for (Booking b:details) {
                        		System.out.println("Booking ID: "+b.getBookingId());
                        		System.out.println("Resident ID: "+b.getResidentId());
                        		System.out.println("Resident Name: "+b.getResidentName());
                        		System.out.println("Duration of stay: "+b.getDurationOfStay());
                        		System.out.println("Number of Adults: "+b.getNumberOfAdults());
                        		System.out.println("Number of Children Above 12: "+b.getNumberOfChildrenAbove12());
                        		System.out.println("Number of Children Above 5: "+b.getNumberOfChildrenAbove5());
                        		System.out.println("CheckIn Date: "+b.getCheckInDate());
                        		System.out.println("CheckOut Date: "+b.getCheckOutDate());
                        		System.out.println("Floor Number: "+b.getFloorNumber());
                        		System.out.println("Room Number: "+b.getRoomNumber());
                        		System.out.println("Preferred Package: "+b.getPreferredPackage());
                        		System.out.println("AC access: "+b.getAcAccess());
                        		System.out.println("Pool access: "+b.getPoolAccess());
                        		System.out.println("Gym access: "+b.getGymAccess());
                        	}
                        }

                        else if(chcust==5) {
                        	
                        	System.out.println("----------Manage ResidentDetails----------");
                        	
                        	System.out.println("Which one you want to update");
                        	System.out.println("1. Update Phone number");
                        	System.out.println("2. Update Occupancy");
                        	int updateChoice=sc.nextInt();
                        	
                        	System.out.println("Please Enter your Resident Type");
                        	String id=sc.next();
                        	
                        	if(id.startsWith("RI")) {
            
                        	switch(updateChoice) {
                        	case 1:
                        		System.out.println("Enter your Phone number");
                        		long phoneNo=sc.nextLong();
                        		
                        		System.out.println("1. Using ResientID");
                        		System.out.println("2. Using IDProof");
                        		System.out.println("3. Using Contact Number");
                        		int phoneChoice=sc.nextInt();
                        		
                        		if(phoneChoice==1) {
                        			System.out.println("Enter your ResidentID");
                        			String residentId=sc.next();
                        			
                        			ri.updateRIResidentPhoneNumberUsingResidentId(phoneNo,residentId);
                        		}
                        		
                        		else if(phoneChoice==2) {
                        			System.out.println("Enter your IDProof");
                        			long idProof=sc.nextLong();
                        			
                        			ri.updateRIResidentPhoneNumberUsingIdProof(phoneNo,idProof);
                        		}
                        		
                        		else if(phoneChoice==3) {
                        			System.out.println("Enter your Contact Number");
                        			long contactNo=sc.nextLong();
                        			
                        			ri.updateRIResidentPhoneNumberUsingContactNumber(phoneNo,contactNo);
                        		}
                        		
                        		else
                        			System.out.println("Invalid Option");
//                        		
                        		break;
                        		
                        	case 2:
                        		System.out.println("Enter number of Adults");
                        		int adults=sc.nextInt();
                        		System.out.println("Enter number of Childern Above12");
                        		int childAbove12=sc.nextInt();
                        		System.out.println("Enter number of Childern Above5");
                        		int childAbove5=sc.nextInt();
                        	    
                        		System.out.println("1. Using ResientID");
                        		System.out.println("2. Using IDProof");
                        		System.out.println("3. Using Contact Number");
                        		int occupyChoice=sc.nextInt();
                        		
                        		if(occupyChoice==1) {
                        			System.out.println("Enter your ResidentID");
                        			String residentId=sc.next();
                        			
                        			ri.updateOccupancyUsingResidentId(adults,childAbove12,childAbove5,residentId);
                        		}
                        		
                        		if(occupyChoice==2) {
                        			System.out.println("Enter your IDProof");
                        			long idProof=sc.nextLong();
                        			
                        			ri.updateOccupancyUsingIdProof(idProof,adults,childAbove12,childAbove5);
                        		}
                        		
                        		if(occupyChoice==3) {
                        			System.out.println("Enter your Contact number");
                        			long contactNo=sc.nextLong();
                        			
                        			ri.updateOccupancyUsingContactNumber(contactNo,adults,childAbove12,childAbove5);
                        		}
                        		break;
                        		
                        		default:
                        			System.out.println("Invalid Option");
                        	}
                        }
                        	else if(id.startsWith("NRI")) {
                        		switch(updateChoice) {

                            	case 1:
                            		System.out.println("Enter your Phone number");
                            		long phoneNo=sc.nextLong();
                            		
                            		System.out.println("1. Using ResientID");
                            		System.out.println("2. Using Passport Number");
                            		System.out.println("3. Using Contact Number");
                            		int phoneChoice=sc.nextInt();
                            		
                            		if(phoneChoice==1) {
                            			System.out.println("Enter your ResidentID");
                            			String residentId=sc.next();
                            			
                            			nri.updateNRIResidentPhoneNumberUsingResidentId(residentId,phoneNo);
                            		}
                            		
                            		else if(phoneChoice==2) {
                            			System.out.println("Enter your Passport number");
                            			String passport=sc.next();
                            			
                            			nri.updateNRIResidentPhoneNumberUsingPassportNumber(passport,phoneNo);
                            		}
                            		
                            		else if(phoneChoice==3) {
                            			System.out.println("Enter your Contact Number");
                            			long contactNo=sc.nextLong();
                            			
                            			nri.updateNRIResidentPhoneNumberUsingContactNumber(phoneNo,contactNo);
                            		}
                            		
                            		else
                            			System.out.println("Invalid Option");
//                            		
                            		break;
                            		
                            	case 2:
                            		System.out.println("Enter number of Adults");
                            		int adults=sc.nextInt();
                            		System.out.println("Enter number of Childern Above12");
                            		int childAbove12=sc.nextInt();
                            		System.out.println("Enter number of Childern Above5");
                            		int childAbove5=sc.nextInt();
                            	    
                            		System.out.println("1. Using ResientID");
                            		System.out.println("2. Using Passport Number");
                            		System.out.println("3. Using Contact Number");
                            		int occupyChoice=sc.nextInt();
                            		
                            		if(occupyChoice==1) {
                            			System.out.println("Enter your ResidentID");
                            			String residentId=sc.next();
                            			
                            			nri.updateOccupancyUsingResidentId(residentId,adults,childAbove12,childAbove5);
                            		}
                            		
                            		if(occupyChoice==2) {
                            			System.out.println("Enter your Passport number");
                            			String passport=sc.next();
                            			
                            			nri.updateOccupancyUsingPassportNumber(passport,adults,childAbove12,childAbove5);
                            		}
                            		
                            		if(occupyChoice==3) {
                            			System.out.println("Enter your Contact number");
                            			long contactNo=sc.nextLong();
                            			
                            			nri.updateOccupancyUsingContactNumber(contactNo,adults,childAbove12,childAbove5);
                            		}
                            		break;
                            		
                            		default:
                            			System.out.println("Invalid Option");
                            	
                        		}
                        	}
                        }
                        else if(chcust==6) {
                        	System.out.println("----------Delete Registration----------");
                        	System.out.println("Enter your Resident ID");
                        	String id=sc.next();
                        	
                        	if(id.startsWith("RI"))
                        		ri.deleteRIResidentDetailsFromDB(id);
                        	else if(id.startsWith("NRI"))
                        		nri.deleteNRIResidentDetailsFromDB(id);
                        	else
                        		System.out.println("Invalid ID");
                       
                         }
                        else if(chcust==7) {
                        	System.out.println("----------View Payment----------");
                        	System.out.print("Please Enter Payment ID");
                            String paymentId = sc.nextLine();

                            List<Payment> payment = ps.viewPaymentDetails(paymentId);

                            if (payment != null) {
                            	for(Payment P:payment) {
                                System.out.println("----------Payment Details--------");
                                System.out.println("Payment ID     : " + P.getPaymentId());
                                System.out.println("Booking ID     : " + P.getBookingId());
                                System.out.println("Resident Name  : " + P.getResidentName());
                                System.out.println("Floor Number   : " + P.getFloorNumber());
                                System.out.println("Room Number    : " + P.getRoomNumber());
                                System.out.println("Check-In Date  : " + P.getCheckInDate());
                                System.out.println("Check-Out Date : " + P.getCheckOutDate());
                                System.out.println("Bill Amount    : ₹" + P.getBillAmount());
                                System.out.println("Payment Method : " + P.getPaymentMethod());
                                System.out.println("Payment Date   : " + P.getPaymentDate());
                            	}
                            } else {
                                System.out.println("❌ No payment found with this ID!");
                            }

                        }
                        else
                        	System.out.println("Invalid option");
                            

                            
                        break;

                    case 2: // Manager Login
                    	System.out.println("----------Manager Login----------");
                        System.out.println("1. Add room details");
                        System.out.println("2. View Booking details");
                        System.out.println("3. View Available rooms");
                        System.out.println("4. View Occupied rooms");
                       
                        int managerChoice = sc.nextInt();
                        sc.nextLine();

                        switch(managerChoice) {
                        case 1:
                        	System.out.println("----------Add Room Details----------");
                            System.out.println("How many Room Details you want to Add?");
                            int noOfRooms = sc.nextInt();
                            sc.nextLine();

                            System.out.println("ROOM_NUMBER:FLOOR_NUMBER:IS_OCCUPIED:MAX_OCCUPANCY:HAS_AC:HAS_SWIMMING_POOL_ACCESS:HAS_GYM_ACCESS");
                           
                            List<String> list=new ArrayList<>();

                            for (int i = 1; i <= noOfRooms; i++) {
                                String roomInput = sc.nextLine();
                                list.add(roomInput);
                               
                            }
                            List<Room> verify = rs.buildRoomList(list);
                            rs.addRoomList(verify);
                            
                            break;
                        case 2:
                        	System.out.println("----------View Booking details----------");
                        	System.out.println("Please enter your Booking ID");
                        	String id=sc.next();
                        	
                        	List<Booking> bookingList=bs.viewBookingDetails(id);
                        	
                        	if(!bookingList.isEmpty()) {
                        		System.out.println("----------Manager Booking Details----------");
                        		for(Booking b:bookingList) {
                        			System.out.println("Booking ID: "+b.getBookingId());
                        			System.out.println("Resident ID: "+b.getResidentId());
                        			System.out.println("Resident Name: "+b.getResidentName());
                        			System.out.println("Duration Of Stay: "+b.getDurationOfStay());
                        			System.out.println("Number Of Adults: "+b.getNumberOfAdults());
                        			System.out.println("Number Of Children Above12: "+b.getNumberOfChildrenAbove12());
                        			System.out.println("Number Of Children Above5: "+b.getNumberOfChildrenAbove5());
                        		    System.out.println("Check In Date: "+b.getCheckInDate());
                        		    System.out.println("Check out Date: "+b.getCheckOutDate());
                        		    System.out.println("Floor Number: "+b.getFloorNumber());
                        		    System.out.println("Room Number: "+b.getRoomNumber());
                        		    System.out.println("Preferred Package: "+b.getPreferredPackage());
                        		    System.out.println("Ac Access: "+b.getAcAccess());
                        		    System.out.println("Pool Access: "+b.getPoolAccess());
                        		    System.out.println("Gym Access: "+b.getGymAccess());
                        		}
                        	}
                        	else
                        		System.out.println("No booking details for Booking ID "+id);
                        	break;
                        	
                        case 3:
                        	System.out.println("----------View Available rooms----------");
                            System.out.println("1. For all rooms");
                            System.out.println("2. For particluar Floor Number");
                            int mChoice=sc.nextInt();
                            
                            if(mChoice==1) {
                            	List<Room> avail=ms.viewAvailableRoom();
                            	if(!avail.isEmpty()) {
                            		System.out.println("All Available rooms");
                            		for(Room r:avail) {
                            			System.out.println("Room Number: "+r.getRoomNumber());
                            			System.out.println("Floor Number: "+r.getFloorNumber());
                            			System.out.println("Is Occupied: "+r.getIsOccupied());
                            			System.out.println("Max Occupancy: "+r.getMaxOccupancy());
                            			System.out.println("Has AC: "+r.getHasAc());
                            			System.out.println("Has Pool Access: "+r.getHasSwimmingPoolAccess());
                            			System.out.println("Has Gym Access: "+r.getHasGymAccess());
                            		}
                            	}
                            	else {
                            		System.out.println("No available rooms right now!");
                            	}
                            }
                            else if(mChoice==2) {
                            	System.out.println("Enter the Floor number(F1,F2,F3,F4)");
                            	String floor=sc.next();
                            	
                            	List<Room> avail=ms.viewAvailableRoom();
                            	if(!avail.isEmpty()) {
                            		System.out.println("All Available rooms in Floor Number "+floor);
                            		for(Room r:avail) {
                            			System.out.println("Room Number: "+r.getRoomNumber());
                            			System.out.println("Floor Number: "+r.getFloorNumber());
                            			System.out.println("Is Occupied: "+r.getIsOccupied());
                            			System.out.println("Max Occupancy: "+r.getMaxOccupancy());
                            			System.out.println("Has AC: "+r.getHasAc());
                            			System.out.println("Has Pool Access: "+r.getHasSwimmingPoolAccess());
                            			System.out.println("Has Gym Access: "+r.getHasGymAccess());
                            		}
                            	}
                            	else {
                            		System.out.println("No available rooms right now in a particular floor number!");
                            	}
                            }
                            else
                            	System.out.println("Invalid option");
                            break;
                        case 4:
                        	System.out.println("----------View Occupied rooms----------");
                        	System.out.println("1. For all rooms");
                        	System.out.println("2. For particular floor number");
                        	System.out.println("3. For particular CheckIn date");
                        	System.out.println("4. For particular CheckOut date");
                        	int Choice=sc.nextInt();
                        	
                        	if(Choice==1) {
                            	List<Room> avail=ms.viewOccupiedRoom();
                            	if(!avail.isEmpty()) {
                            		System.out.println("All Occupied rooms");
                            		for(Room r:avail) {
                            			System.out.println("Room Number: "+r.getRoomNumber());
                            			System.out.println("Floor Number: "+r.getFloorNumber());
                            			System.out.println("Is Occupied: "+r.getIsOccupied());
                            			System.out.println("Max Occupancy: "+r.getMaxOccupancy());
                            			System.out.println("Has AC: "+r.getHasAc());
                            			System.out.println("Has Pool Access: "+r.getHasSwimmingPoolAccess());
                            			System.out.println("Has Gym Access: "+r.getHasGymAccess());
                            		}
                            	}
                            	else {
                            		System.out.println("No Occupied rooms right now!");
                            	}
                            }
                        	 else if(Choice==2) {
                             	System.out.println("Enter the Floor number(F1,F2,F3,F4)");
                             	String floor=sc.next();
                             	
                             	List<Room> avail=ms.viewAvailableRoom();
                             	if(!avail.isEmpty()) {
                             		System.out.println("All Occupied rooms in Floor Number "+floor);
                             		for(Room r:avail) {
                             			System.out.println("Room Number: "+r.getRoomNumber());
                             			System.out.println("Floor Number: "+r.getFloorNumber());
                             			System.out.println("Is Occupied: "+r.getIsOccupied());
                             			System.out.println("Max Occupancy: "+r.getMaxOccupancy());
                             			System.out.println("Has AC: "+r.getHasAc());
                             			System.out.println("Has Pool Access: "+r.getHasSwimmingPoolAccess());
                             			System.out.println("Has Gym Access: "+r.getHasGymAccess());
                             		}
                             	}
                             	else {
                             		System.out.println("No Occupied rooms right now in a particular floor number!");
                             	}
                             }
                        	 else if(Choice==3) {
                        	 
                        	try {
                        	System.out.println("Enter CheckIn Date(dd-MM-yyyy)");
                        	String date=sc.next();
                        	
                        	DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy");
                        	LocalDate ldate=LocalDate.parse(date,format);
                            java.sql.Date sqldate=java.sql.Date.valueOf(ldate);
                            
                            List<Booking> occupy=ms.viewOccupiedRoomForParticularCheckInDate(sqldate);
                            if(!occupy.isEmpty()) {
                            	System.out.println("All Occupied rooms in the CheckIn date "+sqldate);
                            	for(Booking b:occupy) {
                            		System.out.println("Room Number: "+b.getRoomNumber());
                            		System.out.println("Floor Number: "+b.getFloorNumber());
                            	}
                            }
                            else
                            	System.out.println("No Occupied rooms right now in a particular CheckIn date!");
                        }
               
                        
                        catch(DateTimeParseException e) {
                        	System.out.println("Invalid date format! Please enter valid date");
                        }
                        }
                        	 else if(Choice==4) {
                            	 
                             	try {
                             	System.out.println("Enter CheckOut Date(dd-MM-yyyy)");
                             	String date=sc.next();
                             	
                             	DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy");
                             	LocalDate ldate=LocalDate.parse(date,format);
                                 java.sql.Date sqldate=java.sql.Date.valueOf(ldate);
                                 
                                 List<Booking> occupy=ms.viewOccupiedRoomForParticularCheckInDate(sqldate);
                                 if(!occupy.isEmpty()) {
                                 	System.out.println("All Occupied rooms in the CheckOut date "+sqldate);
                                 	for(Booking b:occupy) {
                                 		System.out.println("Room Number: "+b.getRoomNumber());
                                 		System.out.println("Floor Number: "+b.getFloorNumber());
                                 	}
                                 }
                                 else
                                 	System.out.println("No Occupied rooms right now in a particular CheckOut date!");
                             }
                    
                             
                             catch(DateTimeParseException e) {
                             	System.out.println("Invalid date format! Please enter valid date");
                             }
                             }
                        break;
                        default:
                        	System.out.println("Inavlid option");
                        }
                        break;
                    case 3: // Exit
                        System.out.println("----------------------------------");
                        System.out.println("   Thank you for visiting us!");
                        System.out.println("========= Come Again! =========");
                        System.out.println("----------------------------------");
                        return;

                    default:
                        System.out.println("Invalid option. Try again!");
                }
            }
        }
    
}
