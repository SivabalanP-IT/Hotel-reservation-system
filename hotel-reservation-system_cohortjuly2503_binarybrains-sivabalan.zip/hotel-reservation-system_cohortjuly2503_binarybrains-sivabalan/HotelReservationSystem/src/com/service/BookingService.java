package com.service;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
//import java.time.LocalDate;
import com.management.BookingManagement;
import com.model.Booking;
import com.util.ApplicationUtil;

public class BookingService {
	    Scanner sc = new Scanner(System.in);
	    
		BookingManagement bm = new BookingManagement();
		RIResidentService ri = new RIResidentService();
		
		 
		 
		 private static String generateId() {
			// TODO Auto-generated method stub
			 int co=BookingManagement .countBk();
			 int count=co+1;
			 String id="Booking"+count;
			 return id;
//			return null;
		}
		 

//		 String [] arr;
		 public List<Booking> buildBooking(String id, String booking, String floor, String roomNo,
                 String poolAccess, String gymAccess, String ac, String pack) {

			 	List<String> extract = ApplicationUtil.extractBookingDetails(booking);
			 	List<Booking> list = new ArrayList<>();

				String bookingId = BookingService.generateId();
				int duration = Integer.parseInt(extract.get(1));
				int adults = Integer.parseInt(extract.get(2));
				int childAbove12 = Integer.parseInt(extract.get(3));
				int childAbove5 = Integer.parseInt(extract.get(4));
				String name = extract.get(0);
				
				Date currentDate = new Date();
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(currentDate);
				calendar.add(Calendar.DATE, duration);
				Date checkOut = calendar.getTime();
				
				Booking book = new Booking(bookingId, id, name, duration, adults, childAbove12,
				              childAbove5, currentDate, checkOut, floor, roomNo,
				              pack, ac, poolAccess, gymAccess);
				
				list.add(book);
				return list;
			}

	
	
	public boolean addBookingList(List<Booking> list)
	{
		boolean valid=false;
		boolean value=bm.insertBookingList(list);
		if(value) {
			valid=true;
//		System.out.println("Booked Successfully!");
		}
		else
			valid=false;
		
        return valid;
	}
	
	public void cancelBookingFromDB(String id) {
		boolean cancelid = bm.cancelBookingList(id);
		if(cancelid) {
			System.out.println("Booking list cancelled successfully");
		}
		else {
			System.out.println("Cancelation failed");
		}
	}
	public  void updateCheckInAndCheckOutUsingBookingId(String id,Date chkIn,Date chkOut) {
		java.sql.Date sqlChkIn = new java.sql.Date(chkIn.getTime());
	    java.sql.Date sqlChkOut = new java.sql.Date(chkOut.getTime());
		boolean uptchkInOut = bm.updateChkInOut(id,sqlChkIn,sqlChkOut);
		if(uptchkInOut) {
			System.out.println("Updated successfully");
		}
		else {
			System.out.println("Update failed");
		}
	}
	
	public void updatePackageUsingBookingId(String id,String pack) {
		boolean uptPack = bm.updatePackage(id,pack);
		if(uptPack) {
			System.out.println("Package updated successfully");
		}
		else {
			System.out.println("Package update failed");
		}
	}
	public void updateExtraAccessUsingBookingId(String id,String ac,String pool,String gym) {
		boolean uptExtAccess = bm.updateExtraAccess(id,ac,pool,gym);
		if(uptExtAccess) {
			System.out.println("Extra access Updated successully");
		}
		else {
			System.out.println("Extra access update failed");
		}
	}
	public List<Booking> viewBookingDetails(String id) {
		List<Booking> view = bm.viewBookingDetails(id);
		return view;
	}
}
