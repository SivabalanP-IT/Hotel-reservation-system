package com.service;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import com.management.RIResidentManagement;
import com.model.RIResident;
import com.util.ApplicationUtil;
public class RIResidentService {
    
	 RIResidentManagement riManagement=new RIResidentManagement();
//	 RIResident
	 
	 public int addRIResidentList(String details) {
		 
		 List<String> fields = ApplicationUtil.extractToList(details);
	     List<RIResident> residents=build(fields);
	     
	     System.out.println(fields);
	     
	     if(residents.isEmpty()) {
	    	 System.out.println("No valid RI Resident records found.");
//	    	 return;
	     }
	     
	     int inserted=riManagement.RIResidentList(residents);
	     return inserted;
	     
//	     if(inserted)
//	        System.out.println("All records inserted successfully");
//	     else
//	    	 System.out.println("Failed to insert RI Resident records.");
	    }
	 
	public List<RIResident> build(List<String> fields) {
        List<RIResident> residentList = new ArrayList<>();

//        for (String record: fields) {//             String[] values=record.split(":");
//                 residentList.add(r);
//             
             String id=RIResidentService.generateId();
             String name=fields.get(0);
             int age=Integer.parseInt(fields.get(1));
             String gender=fields.get(2);
             long num=Long.parseLong(fields.get(3));
             String mail=fields.get(4);
             String address=fields.get(5);
             int NumberOfAdults=Integer.parseInt(fields.get(6));
             int NumberOfChildrenAbove12=Integer.parseInt(fields.get(7));
             int NumberOfChildrenAbove5=Integer.parseInt(fields.get(8));
             int DurationOfStay=Integer.parseInt(fields.get(9));
             String ResidentType=fields.get(10);
             long IdProofAadharNo=Long.parseLong(fields.get(11));
             
             RIResident r = new RIResident(id,name,age,gender,num,mail,address,NumberOfAdults,NumberOfChildrenAbove12,NumberOfChildrenAbove5,DurationOfStay,ResidentType,IdProofAadharNo);
             residentList.add(r);
        
        return residentList;
    }
	
	 private static final AtomicInteger counter=new AtomicInteger(100);
	 
	 public static String generateId() {
		// TODO Auto-generated method stub
		 String id="RI"+counter.incrementAndGet();
		 return id;
//		return null;
	}
	 
	 public List<RIResident> retreiveRIResidentDetailsForBooking(String riId){
		 List<RIResident> riResident=new ArrayList<>();
		 boolean riDetails=riManagement.checkIdExists(riId);
		 
		 if(riDetails)
			 riResident=riManagement.retreiveRIResidentDetailsForBooking(riId);

		 else
			 riResident=null;
		 
		 return riResident;
	 }
	 
	 public void updateRIResidentPhoneNumberUsingResidentId(long phoneNo,String riId) {
		 	boolean phone=riManagement.updateRIResidentPhoneNumberUsingResidentId(phoneNo,riId);
		 	if(phone)
		 	  System.out.println("Your phone number was updated");
		 	else
		 		System.out.println("Your phone number not updated");
	 }
	 
	 public void updateOccupancyUsingResidentId(int noOfAdults,int childAbove12,int childAbove5,String riId) {
		 boolean occupy=riManagement.updateOccupancyUsingResidentId(noOfAdults,childAbove12,childAbove5,riId);
		 if(occupy)
			 System.out.println("Your Occupancy was updated");
		 else
			 System.out.println("Your Occupancy not updated");
	 }
	 
	 public void updateRIResidentPhoneNumberUsingIdProof(long phoneNo,long idProof) {
		 boolean phone=riManagement.updateRIResidentPhoneNumberUsingIdProof(phoneNo,idProof);
		 if(phone)
			 System.out.println("Your phone number was updated");
		 else
		 		System.out.println("Your phone number not updated");
	 }
	 
	 public void updateOccupancyUsingIdProof(long idProof,int noOfAdults,int childAbove12,int childAbove5) {
		 boolean occupy=riManagement.updateOccupancyUsingIdProof(noOfAdults,childAbove12,childAbove5,idProof);
		 if(occupy)
			 System.out.println("Your Occupancy was updated");
		 else
			 System.out.println("Your Occupancy not updated");
	 }
	 
	 public void updateRIResidentPhoneNumberUsingContactNumber(long phoneNo,long contactNo) {
		 boolean phone=riManagement.updateRIResidentPhoneNumberUsingContactNumber(phoneNo,contactNo);
		 if(phone)
			 System.out.println("Your phone number was updated");
		 else
		 		System.out.println("Your phone number not updated");
	 }
	 
	 public void updateOccupancyUsingContactNumber(long contactNo,int noOfAdults,int childAbove12,int childAbove5) {
		 boolean occupy=riManagement.updateOccupancyUsingContactNumber(noOfAdults,childAbove12,childAbove5,contactNo);
		 if(occupy)
			 System.out.println("Your Occupancy was updated");
		 else
			 System.out.println("Your Occupancy not updated");
	 }
	 
	 public List<RIResident> retreiveRIResidentDetails(String riId){
		 List<RIResident> retrieve=riManagement.retreiveRIResidentDetailsForBooking(riId);
		 return retrieve;
	 }
	 
	 public void deleteRIResidentDetailsFromDB(String riId) {
		 boolean delete=riManagement.deleteRIResidentDetailsFromDB(riId);
		 if(delete)
			 System.out.println("Your details are deleted");
		 else
			 System.out.println("Your details are not deleted");
	 }

	
}
