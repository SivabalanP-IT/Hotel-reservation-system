package com.service;
import java.util.*;
import com.management.*;
import com.model.*;



public class RoomService {
	    private RoomManagement roomDAO = new RoomManagement();

	    public List<Room> buildRoomList(List<String> roomDataList) {
	        List<Room> rooms = new ArrayList<>();
	        for (String data : roomDataList) {
	            String[] details = data.split(":");
	            Room room = new Room(details[0], details[1], details[2],
	                    Integer.parseInt(details[3]), details[4], details[5], details[6]);
	            rooms.add(room);
	        }
	        return rooms;
	    }

	    public void addRoomList(List<Room> rooms) {
	      //  for (Room room : rooms) {
	            roomDAO.insertRoomList(rooms);
	   //     }
	        System.out.println("All rooms added successfully!");
	    }

	    public boolean updateOccupiedStatus(String roomNumber) {
	    	boolean update=false;
	        boolean status=roomDAO.updateOccupiedStatusUsingRoomNumber(roomNumber);
	        
	        if(status)
	        	update=true;
	        else
	        	update=false;
	        
	        return update;
	    }

	    public void deleteRoomDetailsFromDBUsingFloorNumber(String floorNumber) {
	        roomDAO.deleteRoomDetailsFromDBUsingFloorNumber(floorNumber);
	    }

	    public void deleteRoomDetailsFromDBUsingRoomNumber(String roomNumber) {
	        roomDAO.deleteRoomDetailsFromDBUsingRoomNumber(roomNumber);
	    }
	}
   


