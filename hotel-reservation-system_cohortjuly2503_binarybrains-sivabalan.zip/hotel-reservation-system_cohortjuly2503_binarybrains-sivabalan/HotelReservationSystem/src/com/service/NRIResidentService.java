package com.service;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import com.management.NRIResidentManagement;
import com.model.*;
import com.util.ApplicationUtil;
public class NRIResidentService {
    
	 NRIResidentManagement nriManagement=new NRIResidentManagement();
//	 RIResident
	 
	 BookingService bs = new BookingService();
	 
;	 public int addNRIResidentList(String details) {
	 
	 List<String> fields = ApplicationUtil.extractToList(details);
    NRIResident residents=build(fields);
    
    System.out.println(fields);
    
    if(residents==null) {
   	 System.out.println("No valid NRI Resident records found.");
//   	 return;
    }
    
    int inserted=nriManagement.addNRIResidentList(residents);
    return inserted;
    
//    if(inserted)
//       System.out.println("All records inserted successfully");
//    else
//   	 System.out.println("Failed to insert RI Resident records.");
   }

public NRIResident build(List<String> fields) {
    List<NRIResident> residentList = new ArrayList<>();

//    for (String record: fields) {
//         String[] values=record.split(":");
//             residentList.add(r);
//         
         String id=NRIResidentService.generateId();
         String name=fields.get(0);
         int age=Integer.parseInt(fields.get(1));
         String gender=fields.get(2);
         long num=Long.parseLong(fields.get(3));
         String mail=fields.get(4);
         String address=fields.get(5);
         int NumberOfAdults=Integer.parseInt(fields.get(6));
         int NumberOfChildrenAbove12=Integer.parseInt(fields.get(7));
         int NumberOfChildrenAbove5=Integer.parseInt(fields.get(8));
         int DurationOfStay=Integer.parseInt(fields.get(9));
         String ResidentType=fields.get(10);
         String PassportNo=fields.get(11);
	     String PassportType=fields.get(12);
	     String Nationality=fields.get(13);
	     String PurposeForVisit=fields.get(14);
         
         NRIResident r = new NRIResident(id,name,age,gender,num,mail,address,NumberOfAdults,NumberOfChildrenAbove12,NumberOfChildrenAbove5,DurationOfStay,ResidentType,PassportNo,PassportType,Nationality,PurposeForVisit);
         //residentList.add(r);
    
    return r;
}

 
 
 public static String generateId() {
	// TODO Auto-generated method stub
	 int count=NRIResidentManagement.countNri();
	 int count1=count+1;
	 String id="NRI"+count1;
//	 System.out.println("Your Resident ID :"+id);
	 return id;
//	return null;
}

//	public List<NRIResident> build(List<String> details) {
//        List<NRIResident> residentList = new ArrayList<>();
//
////        for (String record: details) 
////        {
//             
//             String id=NRIResidentService.generateId();
//             String name=details.get(0);
//             int age=Integer.parseInt(details.get(1));
//             String gender=details.get(2);
//             long ContactNumber=Long.parseLong(details.get(3));
//             String mail=details.get(4);
//             String address=details.get(5);
//             int NumberOfAdults=Integer.parseInt(details.get(6));
//             int NumberOfChildrenAbove12=Integer.parseInt(details.get(7));
//             int NumberOfChildrenAbove5=Integer.parseInt(details.get(8));
//             int DurationOfStay=Integer.parseInt(details.get(9));
//             String ResidentType=details.get(10);
//             String PassportNo=details.get(11);
//             String PassportType=details.get(12);
//             String Nationality=details.get(13);
//             String PurposeForVisit=details.get(14);
//             
//             NRIResident r=new NRIResident(id,name,age,gender,ContactNumber,mail,address,
//            		             NumberOfAdults,NumberOfChildrenAbove12,NumberOfChildrenAbove5,
//            		             DurationOfStay,ResidentType,PassportNo,PassportType,Nationality,PurposeForVisit);
//             residentList.add(r);
//             
////             System.out.println(record);
////        }
//        
//        return residentList;
//    }
//	
//	 private static final AtomicInteger counter=new AtomicInteger(100);
//	 
//	 public static String generateId() 
//	 {
////		// TODO Auto-generated method stub
//		 String id="NRI"+counter.incrementAndGet();
//		 return id;
////		return null;
//	}
	 
	 public List<NRIResident> retreiveNRIResidentDetailsForBooking(String nriId){
		 List<NRIResident> nriResident=new ArrayList<>();
		 boolean nriDetails=nriManagement.checkIdExists(nriId);
		 
		 if(nriDetails)
			 nriResident=nriManagement.retrieveNRIResidentDetailsForBooking(nriId);
		 else
			 nriResident=null;
		 
		 return nriResident;
	 } 
	 
	 public void updateNRIResidentPhoneNumberUsingResidentId(String residentId,long newPhone)
	 {
		 boolean updated = nriManagement.updatePhoneNumberUsingResidentId(residentId,newPhone);
		 if(updated)
		 {
			 System.out.println("Phone number updated for Resident ID: "+residentId);
		 }
		 else
		 {
			 System.out.println("Failed to update Phone number for Resident ID: " + residentId);
		 }
		 
	 }
	 
	 public void updateOccupancyUsingResidentId(String residentId, int adults, int childrenAbove12, int childrenAbove5) {
		    boolean updated = nriManagement.updateOccupancyUsingResidentId(residentId, adults, childrenAbove12, childrenAbove5);
		    if (updated)
		        System.out.println("Occupancy updated for Resident ID: " + residentId);
		    else
		        System.out.println("Failed to update occupancy for Resident ID: " + residentId);
		}

		public void updateNRIResidentPhoneNumberUsingPassportNumber(String passportNo, long newPhoneNum) {
		    boolean updated = nriManagement.updateNRIResidentPhoneNumberUsingPassportNumber(passportNo, newPhoneNum);
		    if (updated)
		        System.out.println("Phone number updated for Passport No: " + passportNo);
		    else
		        System.out.println("Failed to update phone number for Passport No: " + passportNo);
		}

		public void updateOccupancyUsingPassportNumber(String passportNo, int adults, int childrenAbove12, int childrenAbove5) {
		    boolean updated = nriManagement.updateOccupancyUsingPassportNumber(passportNo, adults, childrenAbove12, childrenAbove5);
		    if (updated)
		        System.out.println("Occupancy updated for Passport No: " + passportNo);
		    else
		        System.out.println("Failed to update occupancy for Passport No: " + passportNo);
		}

	 
	 
	 public void updateNRIResidentPhoneNumberUsingContactNumber(long contactNumber, long newPhone) 
	 {
		 boolean updated = nriManagement.updateNRIResidentPhoneNumberUsingContactNumber(contactNumber, newPhone);
		 if(updated)
		 {
			 System.out.println("Phone number updated for Contact No: " + contactNumber);
		 }
		 else
		 {
			 System.out.println("Failed to update Phone number for Contact No: " + contactNumber);
		 }
	     
	 }
	 
	 public void updateOccupancyUsingContactNumber(long contactNumber, int adults, int childrenAbove12, int childrenAbove5) {
		    boolean updated = nriManagement.updateOccupancyUsingContactNumber(contactNumber, adults, childrenAbove12, childrenAbove5);
		    if (updated)
		        System.out.println("Occupancy updated for Contact No: " + contactNumber);
		    else
		        System.out.println("Failed to update occupancy for Contact No: " + contactNumber);
		}
	 
	 public void deleteNRIResidentDetailsFromDB(String residentId) 
	 {
	     boolean delete=nriManagement.deleteNRIResidentDetailsFromDB(residentId);
	     if(delete)
	        System.out.println("Your Registration deleted successfully.");
	     else
	    	 System.out.println("Your Registration not deleted");
	 }
	 
	 public List<NRIResident> retreiveNRIResidentDetails(String residentId) 
	 {
	     List<NRIResident>resident=new ArrayList<>();
	     resident = nriManagement.retrieveNRIResidentDetailsForBooking(residentId);
	     if (resident != null)
	        System.out.println("✅ Resident details found for ID: " + residentId);
	     else
	        System.out.println("⚠ No resident found with ID: " + residentId);
	     return resident;
   }

	
}