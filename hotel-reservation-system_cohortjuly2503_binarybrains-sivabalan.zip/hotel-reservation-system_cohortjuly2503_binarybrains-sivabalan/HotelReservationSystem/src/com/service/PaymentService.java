package com.service;
import java.util.*;
import com.model.*;
import com.management.PaymentManagement;

public class PaymentService {

    public static String generateId() {
        String prefix = "PAY";
        int randomNum = new Random().nextInt(9000) + 1000; // 1000-9999
        return prefix + randomNum;
    }

    public List<Payment> buildPaymentList(List<Booking> booking, String paymentMethod) {
        
    	List<Payment> pay=new ArrayList<>();
        for(Booking b:booking) {
        String PaymentId=PaymentService.generateId();
        String BookingId=b.getBookingId();
        String ResidentName=b.getResidentName();
        String FloorNumber=b.getFloorNumber();
        String RoomNumber=b.getRoomNumber();
        Date CheckInDate=b.getCheckInDate();
        Date CheckOutDate=b.getCheckOutDate();
        Date PaymentDate=CheckInDate;
        String PaymentMethod=paymentMethod;
        double bill=PaymentService.calculateBillAmount(booking);
        
        Payment p = new Payment(PaymentId,BookingId,ResidentName,FloorNumber,RoomNumber,CheckInDate,CheckOutDate,PaymentDate,PaymentMethod,bill);
        pay.add(p);
        }
        addPaymentList(pay);
        
        
        // Calculate bill amount based on rules
//        double billAmount = calculateBillAmount(booking);
//        p.setBillAmount(billAmount);
        return pay;
    }
    
    public static double calculateBillAmount(List<Booking> booking) {
	    String floorNo=null;
	    int childAbove5=0;
	    int childAbove12=0;
	    int adults=0;
	    int nights=0;
	    String ac=null;
	    
    	for(Booking b:booking) {
    	floorNo=b.getFloorNumber();
    	childAbove5=b.getNumberOfChildrenAbove5();
    	childAbove12=b.getNumberOfChildrenAbove12();
    	adults=b.getNumberOfAdults();
    	nights=b.getDurationOfStay();
    	ac = b.getAcAccess();
    	}
    	
    	double roomRent=0;
    	switch(floorNo) {
    	
    	case "F1": 
    		roomRent=1500;
    		break;
    	case "F2":
    		roomRent=2000;
    		break;
    	case "F3":
    		roomRent=2500;
    		break;
    	case "F4":
    		roomRent=4000;
    		break;
    	default:
    		System.out.println("Invalid floor number!");
    		
    	}
    	
    	
    	
    	double adultCharge = adults * roomRent;
        double childAbove12Charge = childAbove12 * (0.4 * roomRent);
        double child6to12Charge = childAbove5 * 500;
        double childUnder5Charge = 0;
        double totalPeopleCharge = adultCharge + childAbove12Charge + child6to12Charge + childUnder5Charge;
        
        double acCharge=0;
        
        if(ac.equalsIgnoreCase("yes"))
        	acCharge=750;
        else if(ac.equalsIgnoreCase("no"))
        	acCharge=0;
        
        double totalRoomCost = (totalPeopleCharge + acCharge) * nights;
        
        double foodCharge = 0;
        double discount = 0;
        String packageInfo = "";
        
        if(floorNo.equalsIgnoreCase("F4")) {
        	packageInfo = "Package 3: Complimentary breakfast, dinner, pool, and gym";
            foodCharge = 0;
        }
        
        else if (nights > 3) {
            packageInfo = "Package 1: Complimentary breakfast and 10% discount";
            discount = 0.10;
        } 
        
        else {
            packageInfo = "Package 2: 10% of room rent per day for breakfast and dinner";
            foodCharge = 0.10 * roomRent * nights;
        }

        double subtotal = totalRoomCost + foodCharge;
        double discountAmount = subtotal * discount;
        double finalBill = subtotal - discountAmount;
        
        return finalBill;
        }
//    private double calculateBillAmount(Booking b) {
//        long days = (b.getCheckOutDate().getTime() - b.getCheckInDate().getTime()) / (1000 * 60 * 60 * 24);
//        int daysStayed = (int) (days == 0 ? 1 : days);
//
//        double roomRate = 0;
//        switch (b.getFloorNumber()) {
//            case "1": roomRate = 1500; break;
//            case "2": roomRate = 2000; break;
//            case "3": roomRate = 2500; break;
//            case "4": roomRate = 4000; break;
//        }
//
//        double total = roomRate * daysStayed;
//
//        // Add-on services
//        if ("Yes".equalsIgnoreCase(b.getAcAccess())) total += 750;
//        if ("Yes".equalsIgnoreCase(b.getPoolAccess())) total += 500;
//        if ("Yes".equalsIgnoreCase(b.getGymAccess())) total += 500;
//
//        // Apply package rules
//        switch (b.getPreferredPackage()) {
//            case "gold": // more than 3 nights
//                if (daysStayed > 3) total = total - (total * 0.10);
//                break;
//            case "silver": // less than 3 nights
//                if (daysStayed < 3) total += (total * 0.10);
//                break;
//            case "Primimum": // floor 4 customers
//                if (b.getFloorNumber().equals("4")) total = 4000 * daysStayed;
//                break;
//        }
//
//        return total;
//    }
//
    public void addPaymentList(List<Payment> p) {
        PaymentManagement manage = new PaymentManagement();
        boolean result = manage.insertPaymentList(p);
//        if (result)
//            System.out.println("Payment successfully added for booking ID: ");
//        else
//            System.out.println("Failed to add payment.");
    }
//
    public List<Payment> viewPaymentDetails(String id) {
    	PaymentManagement manage = new PaymentManagement();
    	List<Payment> payment=manage.viewPaymentDetails(id);
        List<Payment> pay = new ArrayList<>();
      
        	for(Payment p:payment) {
            String payId=p.getPaymentId();
            String bid=p.getBookingId();
            String name=p.getResidentName();
            String floor=p.getFloorNumber();
            String room=p.getRoomNumber();
            Date checkIn=p.getCheckInDate();
            Date checkOut=p.getCheckOutDate();
            Date paydate=p.getPaymentDate();
            String method=p.getPaymentMethod();
            double bill=p.getBillAmount();
            Payment py=new Payment(payId,bid,name,floor,room,checkIn,checkOut,paydate,method,bill);
            pay.add(py);
            
        	}
      
        return pay;
    }
    
    
    }
  