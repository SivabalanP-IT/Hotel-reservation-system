package com.service;
import java.util.*;

import com.model.*;
import com.management.*;

public class ManagerService {
	
	ManagerManagement m=new ManagerManagement();
	
	
	public Booking viewBookingDetails(String bookingId) {
        // TODO: Implement logic to retrieve booking details from database
		Booking b=m.viewBookingDetails(bookingId);
		System.out.println(b);
        return b;
    }

    public List<Room> viewAvailableRoom() {
        // TODO: Implement logic to retrieve available rooms
    
    	return m.viewAvailableRoom();
    }
    public List<Room> viewOccupiedRoom() {
        // TODO: Implement logic to retrieve occupied rooms
        return m.viewOccupiedRoom();
    }

    
    public List<Room> viewAvailableRoomForParticularFloorNumber(String floorNumber) {
        // TODO: Implement logic to retrieve available rooms for a floor
    	List<Room> list=m.viewAvailableRoomForParticularFloorNumber(floorNumber);
        return list ;
    }

    
    public List<Room> viewOccupiedRoomForParticularFloorNumber(String floorNumber) {
        // TODO: Implement logic to retrieve occupied rooms for a floor
    	List<Room> list=viewOccupiedRoomForParticularFloorNumber(floorNumber);
        return list;
    }

    
    public List<Booking> viewOccupiedRoomForParticularCheckInDate(Date checkInDate) {
        // TODO: Implement logic to retrieve rooms based on check-in date
    	List<Booking> list=viewOccupiedRoomForParticularCheckInDate(checkInDate);
        return list;
    }

   
   public List<Booking> viewOccupiedRoomForParticularCheckOutDate(Date checkOutDate){
	   
	   List<Booking> list=viewOccupiedRoomForParticularCheckOutDate(checkOutDate);
       return list;
   }

}