package com.management;
import java.sql.*;
import java.util.*;
import java.util.List;

import com.management.*;
import com.model.RIResident;
import com.service.*;
public class RIResidentManagement{
	public int RIResidentList(List<RIResident> details) {
		int row=0;
		   try {
		   Connection con=DBConnectionManager.establishConnection();
		   PreparedStatement pst=con.prepareStatement("insert into resident values(?)");
		   Statement pstate = con.createStatement();
		   ResultSet rst = pstate.executeQuery("SELECT RESIDENT_ID FROM resident ORDER BY RESIDENT_ID DESC LIMIT 1");
		   
		   int id = 0;
	       if (rst.next()) {
	           String lastId = rst.getString("RESIDENT_ID"); // e.g. "Booking5"
	           id = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
	       }
		   for(RIResident r:details) {
			   id++;
			   r.setResidentId("RI"+id);
			   pst.setString(1,r.getResidentId());
			   pst.executeUpdate();
		   }
		   
		   PreparedStatement state=con.prepareStatement("insert into riresident values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
		   Statement stmt = con.createStatement();
		   ResultSet rs = stmt.executeQuery("SELECT RESIDENT_ID FROM riresident ORDER BY RESIDENT_ID DESC LIMIT 1");
		   
		   int idNum = 0;
	       if (rs.next()) {
	           String lastId = rs.getString("RESIDENT_ID"); // e.g. "Booking5"
	           idNum = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
	       }
		   for(RIResident r:details) {
			   idNum++;
			   r.setResidentId("RI"+idNum);
			   
			   state.setString(1,r.getResidentId());
			   state.setString(2,r.getResidentName());
			   state.setInt(3,r.getAge());
			   state.setString(4,r.getGender());
			   state.setLong(5, r.getContactNumber());
			   state.setString(6,r.getEmail());
			   state.setString(7,r.getAddress());
			   state.setInt(8,r.getNumberOfAdults());
			   state.setInt(9,r.getNumberOfChildrenAbove12());
			   state.setInt(10,r.getNumberOfChildrenAbove5());
			   state.setInt(11,r.getDurationOfStay());
			   state.setString(12,r.getResidentType());
			   state.setLong(13,r.getIdProofAadharNo());
//			   state.addBatch();
			   state.executeUpdate();
			   
//			   found=true;
			   row++;
		   }
		   
		   System.out.println(row+" Inserted successfully");
//		   return true;
	   }
		   catch(Exception e) {
			    e.printStackTrace();
		   }
//		   return found; 
		   return row;
	}
	   public boolean checkIdExists(String riId){
		   
//		   List<String> riDetails=new ArrayList<>();
		   boolean idFound=false;
		   
		   try {
			   Connection con=DBConnectionManager.establishConnection();
			   PreparedStatement state=con.prepareStatement("select * from riresident where RESIDENT_ID=?");
			   state.setString(1, riId);
			   ResultSet rs=state.executeQuery();
			   
			   while(rs.next()) {
				   idFound=true;
				   
			   }
		   }
			   catch(Exception e) {
				   e.printStackTrace();
				   idFound=false;
			   }
//		   System.out.println(riDetails);
		   return idFound;
		   }
	   
	  public boolean updateRIResidentPhoneNumberUsingResidentId(long phoneNo,String riId) {
		  boolean update=false;
		  try {
			  Connection con=DBConnectionManager.establishConnection();
			  PreparedStatement state=con.prepareStatement("update riresident set CONTACT_NUMBER=? where RESIDENT_ID=?");
			  state.setLong(1, phoneNo);
			  state.setString(2, riId);
			  int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
		  }
		  catch(Exception e) {
			  e.printStackTrace();
		  }
		  return update;
	  }
			  
		 public boolean updateOccupancyUsingResidentId(int adults,int childAbove12,int childAbove5,String riId) {
			 boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement state=con.prepareStatement("update riresident set NUMBER_OF_ADULTS=?,NUMBER_OF_CHILDREN_ABOVE12=?,NUMBER_OF_CHILDREN_ABOVE5=? where RESIDENT_ID=?");
				  state.setInt(1, adults);
				  state.setInt(2, childAbove12);
				  state.setInt(3, childAbove5);
				  state.setString(4, riId);
				  int row=state.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
		 }
	  
		 public boolean updateRIResidentPhoneNumberUsingIdProof(long phoneNo,long idProof) {
			 boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement state=con.prepareStatement("update riresident set CONTACT_NUMBER=? where IDPROOF_AADHARNO=?");
				  state.setLong(1,phoneNo);
				  state.setLong(2, idProof);
				  int row=state.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
		 }
		 
		 public boolean updateOccupancyUsingIdProof(int adults,int childAbove12,int childAbove5,long idProof) {
			 boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement state=con.prepareStatement("update riresident set NUMBER_OF_ADULTS=?,NUMBER_OF_CHILDREN_ABOVE12=?,NUMBER_OF_CHILDREN_ABOVE5=? where IDPROOF_AADHARNO=?");
				  state.setInt(1, adults);
				  state.setInt(2, childAbove12);
				  state.setInt(3, childAbove5);
				  state.setLong(4, idProof);
				  int row=state.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
		 }
		 
		 public boolean updateRIResidentPhoneNumberUsingContactNumber(long phoneNo,long contactNo) {
			 boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement state=con.prepareStatement("update riresident set CONTACT_NUMBER=? where CONTACT_NUMBER=?");
				  state.setLong(1,phoneNo);
				  state.setLong(2,contactNo);
				  int row=state.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
		 }
		 
		 public boolean updateOccupancyUsingContactNumber(int adults,int childAbove12,int childAbove5,long phoneNo) {
			 boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement state=con.prepareStatement("update riresident set NUMBER_OF_ADULTS=?,NUMBER_OF_CHILDREN_ABOVE12=?,NUMBER_OF_CHILDREN_ABOVE5=? where CONTACT_NUMBER=?");
				  state.setInt(1, adults);
				  state.setInt(2, childAbove12);
				  state.setInt(3, childAbove5);
				  state.setLong(4, phoneNo);
				  int row=state.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
		 }
		 
	   public List<RIResident> retreiveRIResidentDetailsForBooking(String riId) {
		   List<RIResident> riResident=new ArrayList<>();
		   try {
			   Connection con=DBConnectionManager.establishConnection();
			   PreparedStatement state=con.prepareStatement("select * from riresident where RESIDENT_ID=?");
			   state.setString(1, riId);
			   ResultSet rs=state.executeQuery();
			   
			   while(rs.next()) {
				   
				   String id=rs.getString(1);
				   String name=rs.getString(2);
				   int age=rs.getInt(3);
				   String gender=rs.getString(4);
				   long num=rs.getLong(5);
				   String mail=rs.getString(6);
				   String address=rs.getString(7);
				   int noOfAdults=rs.getInt(8);
				   int noOfChildAbove12=rs.getInt(9);
				   int noOfChildAbove5=rs.getInt(10);
				   int duration=rs.getInt(11);
				   String type=rs.getString(12);
				   long proof=rs.getLong(13);
				    
				   RIResident ri=new RIResident(id,name,age,gender,num,mail,address,noOfAdults,noOfChildAbove12,noOfChildAbove5,
						                     duration,type,proof);
				   riResident.add(ri);
			   }
		   }
		   catch(Exception e) {
			   e.printStackTrace();
		   }
		   
		   return riResident;
	}
	   
	   public boolean deleteRIResidentDetailsFromDB(String riId) {
		   boolean update=false;
			  try {
				  Connection con=DBConnectionManager.establishConnection();
				  PreparedStatement st=con.prepareStatement("delete from booking where RESIDENT_ID=?");
				  st.setString(1, riId);
				  int row=st.executeUpdate();
				  if(row>0)
					  update=true;
				  else
					  update=false;
				  if(update) {
				  PreparedStatement state=con.prepareStatement("delete from riresident where RESIDENT_ID=?");
				  state.setString(1, riId);
				  int row1=state.executeUpdate();
				  if(row1>0)
					  update=true;
				  else
					  update=false;
			  }
			  }
			  catch(Exception e) {
				  e.printStackTrace();
			  }
			  return update;
	   }
}