package com.management;
import java.sql.*;

import java.util.*;
import com.model.*;
public class RoomManagement {

    
	public void insertRoomList(List<Room> roomList) {
        String sql = "INSERT INTO ROOM (ROOM_NUMBER, FLOOR_NUMBER, IS_OCCUPIED, MAX_OCCUPANCY, HAS_AC, HAS_SWIMMING_POOL_ACCESS, HAS_GYM_ACCESS) VALUES (?, ?, ?, ?, ?, ?, ?)";
        int count = 0;

        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            for (Room room : roomList) {
                stmt.setString(1, room.getRoomNumber());
                stmt.setString(2, room.getFloorNumber());
                stmt.setString(3, room.getIsOccupied());
                stmt.setInt(4, room.getMaxOccupancy());
                stmt.setString(5, room.getHasAc());
                stmt.setString(6, room.getHasSwimmingPoolAccess());
                stmt.setString(7, room.getHasGymAccess());

                stmt.addBatch(); // adds to batch
            }

            int[] result = stmt.executeBatch(); // executes all insertions at once
            for (int r : result) {
                if (r > 0) count++;
            }
            System.out.println("✅ " + count + " room(s) inserted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public boolean updateOccupiedStatusUsingRoomNumber(String roomNumber) {
    	boolean update=false;
        String sql = "UPDATE ROOM SET IS_OCCUPIED = 'Yes' WHERE ROOM_NUMBER = ?";

        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
        	
            stmt.setString(1, roomNumber);

            int rows = stmt.executeUpdate();
            if (rows > 0)
                update=true;
            else
                update=false;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return update;
    }

 
    public void deleteRoomDetailsFromDBUsingFloorNumber(String floorNumber) {
        String sql = "DELETE FROM ROOM WHERE FLOOR_NUMBER = ?";

        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, floorNumber);
            int rows = stmt.executeUpdate();

            if (rows > 0)
                System.out.println("✅ Rooms deleted from Floor " + floorNumber);
            else
                System.out.println("⚠️ No rooms found for Floor " + floorNumber);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

  
    public void deleteRoomDetailsFromDBUsingRoomNumber(String roomNumber) {
        String sql = "DELETE FROM ROOM WHERE ROOM_NUMBER = ?";

        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, roomNumber);
            int rows = stmt.executeUpdate();

            if (rows > 0)
                System.out.println("✅ Room deleted successfully: " + roomNumber);
            else
                System.out.println("⚠️ No room found with Room Number: " + roomNumber);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

  
    public Room viewRoomDetails(String roomNumber) {
        String sql = "SELECT * FROM ROOM WHERE ROOM_NUMBER = ?";
        Room room = null;

        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, roomNumber);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                room = new Room(
                    rs.getString("ROOM_NUMBER"),
                    rs.getString("FLOOR_NUMBER"),
                    rs.getString("IS_OCCUPIED"),
                    rs.getInt("MAX_OCCUPANCY"),
                    rs.getString("HAS_AC"),
                    rs.getString("HAS_SWIMMING_POOL_ACCESS"),
                    rs.getString("HAS_GYM_ACCESS")
                );

                System.out.println("✅ Room Details Found:");
                System.out.println("Room Number: " + room.getRoomNumber());
                System.out.println("Floor: " + room.getFloorNumber());
                System.out.println("Occupied: " + room.getIsOccupied());
                System.out.println("Max Occupancy: " + room.getMaxOccupancy());
                System.out.println("AC: " + room.getHasAc());
                System.out.println("Pool Access: " + room.getHasSwimmingPoolAccess());
                System.out.println("Gym Access: " + room.getHasGymAccess());
            } else {
                System.out.println("⚠️ No room found with Room Number: " + roomNumber);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return room;
    }


}
	

