package com.management;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.model.*;


public class ManagerManagement {

    public Booking viewBookingDetails(String bookingId) {
        Booking booking = null;
        String query = "SELECT * FROM booking WHERE BOOKING_ID = ?";
        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, "BOOKING_ID");
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                booking = new Booking(
                    rs.getString("BOOKING_ID"),
                    rs.getString("RESIDENT_ID"),
                    rs.getString("RESIDENT_NAME"),
                    rs.getInt("DURATION_OF_STAY"),
                    rs.getInt("NUMBER_OF_ADULTS"),
                    rs.getInt("NUMBER_OF_CHILDREN_ ABOVE12"),
                    rs.getInt("NUMBER_OF_CHILDREN_ABOVE5"),                    	
                    rs.getDate("CHECK_IN_DATE"),
                    rs.getDate("CHECK_OUT_DATE"),
                    rs.getString("FLOOR_NUMBER"),
                    rs.getString("ROOM_NUMBER"),
                    rs.getString("PREFERRED_PACKAGE"),
                    rs.getString("AC_ACCESS"),
                    rs.getString("POOL_ACCESS"),
                    rs.getString("GYM_ACCESS")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return booking;
    }


    public List<Room> viewAvailableRoom() {
    	List<Room> list =new ArrayList<Room>();
        String query = "SELECT room_number FROM room WHERE IS_OCCUPIED = 'no'";
        try (Connection conn = DBConnectionManager.establishConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
        	 
            Room r=new Room();
            while (rs.next()) {
            	String roomNo=rs.getString("ROOM_NUMBER");
            	r.setRoomNumber(roomNo);
                list.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Room> viewOccupiedRoom() {
        List<Room> occupiedRooms = new ArrayList<>();
        String query = "SELECT * FROM room WHERE IS_OCCUPIED = 'yes'";
        try (Connection conn = DBConnectionManager.establishConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
        	Room r=new Room();
            while (rs.next()) {
            	String roomNo=rs.getString("ROOM_NUMBER");
            	String floorNum=rs.getString(2);
            	String Is=rs.getString(3);
            	int max=rs.getInt(4);
            	String ac=rs.getString(5);
            	String pool=rs.getString(6);
            	String gym=rs.getString(7);
            	
            	r.setRoomNumber(roomNo);
            	r.setFloorNumber(floorNum);
            	r.setIsOccupied(Is);
            	r.setMaxOccupancy(max);
            	r.setHasAc(ac);
            	r.setHasSwimmingPoolAccess(pool);
            	r.setHasGymAccess(gym);
            	occupiedRooms.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return occupiedRooms;
    }

    
    public List<Room> viewAvailableRoomForParticularFloorNumber(String floorNumber) {
        List<Room> rooms = new ArrayList<>();
        String query = "SELECT room_number FROM room WHERE IS_OCCUPIED = 'no' AND floor_number = ?";
        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, floorNumber);
            ResultSet rs = ps.executeQuery();
            Room r=new Room();
            String roomNo = null;
            while(rs.next()) {
            	roomNo=rs.getString("ROOM_NUMBER");
            	
            	
            	r.setRoomNumber(roomNo);
            	rooms.add(r);
            }
            String update="UPDATE room SET IS_OCCUPIED='yes' WHERE ROOM_NUMBER=?";
        	PreparedStatement ps1 = conn.prepareStatement(update);
        	ps1.setString(1,roomNo);
        	ps1.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

    public List<Room> viewOccupiedRoomForParticularFloorNumber(String floorNumber) {
        List<Room> rooms = new ArrayList<>();
        String query = "SELECT room_number FROM room WHERE IS_OCCUPIED = 'yes' AND floor_number = ?";
        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setString(1, floorNumber);
            ResultSet rs = ps.executeQuery();
            Room r=new Room();
            while (rs.next()) {
            	String roomNo=rs.getString("ROOM_NUMBER");
            	r.setRoomNumber(roomNo);
            	rooms.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }

 
    public List<Booking> viewOccupiedRoomForParticularCheckInDate(Date checkInDate) {
        List<Booking> rooms = new ArrayList<>();
        String query = "SELECT room_number FROM booking WHERE CHECK_IN_DATE = ?";
        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setDate(1,checkInDate);
            ResultSet rs = ps.executeQuery();
            Booking r=new Booking();
            while (rs.next()) {
            	String roomNo=rs.getString("ROOM_NUMBER");
            	r.setRoomNumber(roomNo);
            	rooms.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }
    public List<Booking> viewOccupiedRoomForParticularCheckOutDate(Date checkOutDate){
    	List<Booking> rooms = new ArrayList<>();
        String query = "SELECT room_number FROM booking WHERE CHECK_OUT_DATE = ?";
        try (Connection conn = DBConnectionManager.establishConnection();
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setDate(1, checkOutDate);
            ResultSet rs = ps.executeQuery();
            Booking r=new Booking();
            while (rs.next()) {
            	String roomNo=rs.getString("ROOM_NUMBER");
            	r.setRoomNumber(roomNo);
            	rooms.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rooms;
    }
}