package com.management;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.model.Booking;


public class BookingManagement {

	public boolean insertBookingList(List<Booking> list) {
	    int row = 0;
	    boolean flag=false;
	    try {
	    	Connection con = DBConnectionManager.establishConnection();
	    	PreparedStatement state = con.prepareStatement("INSERT INTO BOOKING (BOOKING_ID,RESIDENT_ID, RESIDENT_NAME, DURATION_OF_STAY, NUMBER_OF_ADULTS, NUMBER_OF_CHILDREN_ABOVE12, NUMBER_OF_CHILDREN_ABOVE5, CHECK_IN_DATE, CHECK_OUT_DATE, FLOOR_NUMBER, ROOM_NUMBER, PREFERRED_PACKAGE, AC_ACCESS, POOL_ACCESS, GYM_ACCESS) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

//		Statement stmt = con.createStatement();
                     
//	    	 ResultSet rs = stmt.executeQuery("SELECT BOOKING_ID FROM booking ORDER BY BOOKING_ID DESC LIMIT 1");
//	    	 int idNum = 0;
//	         if (rs.next()) {
//	             String lastId = rs.getString("BOOKING_ID"); // e.g. "Booking5"
//	             idNum = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
//	         }
 
	        for (Booking b : list) {
	        	
	        	
	        	
	            state.setString(1, b.getBookingId());
	            state.setString(2, b.getResidentId());
	            state.setString(3, b.getResidentName());
	            state.setInt(4, b.getDurationOfStay());
	            state.setInt(5, b.getNumberOfAdults());
	            state.setInt(6, b.getNumberOfChildrenAbove12());
	            state.setInt(7, b.getNumberOfChildrenAbove5());
	            state.setDate(8, new java.sql.Date(b.getCheckInDate().getTime()));
	            state.setDate(9, new java.sql.Date(b.getCheckOutDate().getTime()));
	            state.setString(10, b.getFloorNumber());
	            state.setString(11, b.getRoomNumber());
	            state.setString(12, b.getPreferredPackage());
	            state.setString(13, b.getAcAccess());
	            state.setString(14, b.getPoolAccess());
	            state.setString(15, b.getGymAccess());

	            row=state.executeUpdate();
	           
	        }
	        if(row>0) {
	        	flag=true;
	        }
	        else {
	        	flag=false;
	        }

//	        con.commit(); // ensure changes are saved
	        System.out.println(row + " booking(s) inserted successfully.");
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return flag;
	}
	public static int countBk() {
		int count=0;
		 try {
		    	Connection con = DBConnectionManager.establishConnection();
		    	PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) FROM booking");
		    	ResultSet rs=pst.executeQuery();
		    	
		    	while(rs.next()) {
		    		count+=rs.getInt(1);
		    	}
		    	
		 }
		 catch(Exception e) {
			 
		 }

		return count;
		
	}

	
	public boolean cancelBookingList(String id) {
		boolean flag = false;
		try {
			Connection con = DBConnectionManager.establishConnection();
			PreparedStatement ps = con.prepareStatement("delete FROM payment WHERE BOOKING_ID = ?");
            ps.setString(1,id);
            int row= ps.executeUpdate();
            if(row>0)
           	 flag=true;
            else
           	 flag=false;
            
            if(flag) {
			PreparedStatement pcancel = con.prepareStatement("delete from booking where BOOKING_ID=?");
			pcancel.setString(1, id);
			int row1= pcancel.executeUpdate();
			if(row1>0) 
				flag = true;
			else
				flag = false;
            }
			
		}
		catch(Exception e) {
			e.getMessage();
		}
		return flag;
	}
	
	public boolean updateChkInOut(String id,java.sql.Date chkIn,java.sql.Date chkOut) {
		boolean flag = false;
		try {
			Connection con = DBConnectionManager.establishConnection();
			PreparedStatement puptchk = con.prepareStatement("update booking set CHECK_IN_DATE=?,CHECK_OUT_DATE=? where BOOKING_ID=?");
			puptchk.setDate(1, chkIn);
			puptchk.setDate(2, chkOut);
			puptchk.setString(3, id);
			int row = puptchk.executeUpdate();
			if(row>0) {
				flag = true;
			    System.out.println("updated");
			}
			else {
				flag = false;
			System.out.println("not updated");
			}
			
		}
		catch(Exception e) {
			e.getMessage();
		}
		return flag;
	}
	
	public boolean updatePackage(String id,String pack) {
		boolean flag = false;
		try {
			Connection con = DBConnectionManager.establishConnection();
			PreparedStatement puptpack = con.prepareStatement("update booking set PREFERRED_PACKAGE=? where BOOKING_ID=?");
			puptpack.setString(1, pack);
			puptpack.setString(2, id);
			int row = puptpack.executeUpdate();
			if(row>0) 
				flag = true;
			else
				flag = false;
			
		}
		catch(Exception e) {
			e.getMessage();
		}
		return flag;
	}
	
	public boolean updateExtraAccess(String id,String ac,String pool,String gym) {
		boolean flag = false;
		try {
			Connection con = DBConnectionManager.establishConnection();
			PreparedStatement puptExtraAcc = con.prepareStatement("update booking set AC_ACCESS=?,POOL_ACCESS=?,GYM_ACCESS=? where BOOKING_ID=?");
			puptExtraAcc.setString(1, ac);
			puptExtraAcc.setString(2, pool);
			puptExtraAcc.setString(3, gym);
			puptExtraAcc.setString(4, id);
			int row = puptExtraAcc.executeUpdate();
			if(row>0) 
				flag = true;
			else
				flag = false;
			
		}
		catch(Exception e) {
			e.getMessage();
		}
		return flag;
	}
	
	public List<Booking> viewBookingDetails(String id){
		List<Booking> bookingList = new ArrayList<>();
		try {
			Connection con = DBConnectionManager.establishConnection();
			PreparedStatement pview = con.prepareStatement("select * from booking where BOOKING_ID=?");
			pview.setString(1, id);
			ResultSet rs = pview.executeQuery();
			while (rs.next()) {
				String bookId= rs.getString(1);
				String resId= rs.getString(2);
				String resName = rs.getString(3);
				int durDate = rs.getInt(4);
				int noOfAdults = rs.getInt(5);
				int child12 = rs.getInt(6);
				int child5 = rs.getInt(7);
				Date chkIn = rs.getDate(8);
				Date chkOut = rs.getDate(9);
				String floor = rs.getString(10);
				String room = rs.getString(11);
				String pack = rs.getString(12);
				String ac = rs.getString(13);
				String pool = rs.getString(14);
				String gym = rs.getString(15);
	                    
				Booking b = new Booking(bookId,resId,resName,durDate,noOfAdults,child12,child5,chkIn,chkOut,floor,room,pack,ac,pool,gym);
	                bookingList.add(b);
	            }
			}
		    catch(Exception e) {
		    	e.getMessage();
		}
		return bookingList;
	}


}
