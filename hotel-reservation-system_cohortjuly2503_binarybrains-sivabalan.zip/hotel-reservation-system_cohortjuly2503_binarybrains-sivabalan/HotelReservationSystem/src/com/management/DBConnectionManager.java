package com.management;
import java.sql.*;
import java.io.*;
import java.util.*;
public class DBConnectionManager {
	
	public static Connection establishConnection() {
		
		 Connection con=null;
		 Properties pro=new Properties();
		 
		 try {
			 FileInputStream file=new FileInputStream("database.properties");
			 pro.load(file);
			 
			 Class.forName(pro.getProperty("DB_DRIVER_CLASS"));
			 
			 String url=pro.getProperty("DB_URL");
			 String username=pro.getProperty("DB_USERNAME");
			 String password=pro.getProperty("DB_PASSWORD");
			 
			 con=DriverManager.getConnection(url,username,password);
//			 System.out.println("Database connected successful");
		 }
		 catch(Exception e) {
			 System.out.println("Database not connected");
//			 e.printStackTrace();
		 }
		 return con;
	}
     
}
