package com.management;
import java.sql.*;
import java.util.*;
import java.util.List;

import com.management.*;
import com.model.NRIResident;
import com.service.*;


public class NRIResidentManagement {

    // ✅ Method to insert NRI Residents
	public int addNRIResidentList(NRIResident details) {
		int row=0;
		Connection con = null;
		   try {
		   con=DBConnectionManager.establishConnection();
		   PreparedStatement pst=con.prepareStatement("insert into resident values(?)");
		   Statement pstate = con.createStatement();
		   ResultSet rst = pstate.executeQuery("SELECT RESIDENT_ID FROM resident ORDER BY RESIDENT_ID DESC LIMIT 1");
		   
//		   int id = 0;
//	       if (rst.next()) {
//	    	   //System.out.println(rst.getString());
//	           String lastId = rst.getString("RESIDENT_ID"); // e.g. "Booking5"
//	           id = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
//	       }
//		   
//			   id++;
//			   r.setResidentId("NRI"+id);
			   pst.setString(1,details.getResidentId());
			   //System.out.println(r.getResidentId());
			   pst.executeUpdate();
		   
		   
		   PreparedStatement state=con.prepareStatement("insert into nriresident values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		   Statement stmt = con.createStatement();
		   ResultSet rs = stmt.executeQuery("SELECT RESIDENT_ID FROM nriresident ORDER BY RESIDENT_ID DESC LIMIT 1");
		   
//		   int idNum = 0;
//	       if (rs.next()) {
//	           String lastId = rs.getString("RESIDENT_ID"); // e.g. "Booking5"
//	           idNum = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
//	       }
//		   
			   
			   
			   state.setString(1,details.getResidentId());
			   state.setString(2,details.getResidentName());
			   state.setInt(3,details.getAge());
			   state.setString(4,details.getGender());
			   state.setLong(5, details.getContactNumber());
			   state.setString(6,details.getEmail());
			   state.setString(7,details.getAddress());
			   state.setInt(8,details.getNumberOfAdults());
			   state.setInt(9,details.getNumberOfChildrenAbove12());
			   state.setInt(10,details.getNumberOfChildrenAbove5());
			   state.setInt(11,details.getDurationOfStay());
			   state.setString(12,details.getResidentType());
			   state.setString(13, details.getPassportNo());
	           state.setString(14, details.getPassportType());
	           state.setString(15, details.getNationality());
	           state.setString(16, details.getPurposeForVisit());
//			   state.addBatch();
			   state.executeUpdate();
			   
//			   found=true;
			 
		   System.out.println("Inserted successfully");
//		   return true;
	   }
		   catch(Exception e) {
			    e.printStackTrace();
		   }
//		   return found; 
		   return row;
	}
	public static int countNri() {
		int count=100;
		 try {
		    	Connection con = DBConnectionManager.establishConnection();
		    	PreparedStatement pst = con.prepareStatement("SELECT COUNT(*) FROM nriresident");
		    	ResultSet rs=pst.executeQuery();
		    	
		    	while(rs.next()) {
		    		count+=rs.getInt(1);
		    	}
		    	
		 }
		 catch(Exception e) {
			 
		 }

		return count;
		
	}

//	public int addNRIResidentList(List<NRIResident> details) {
//	    int row = 0;
//	    try {
//	    	Connection con = DBConnectionManager.establishConnection();
//	    	PreparedStatement pst = con.prepareStatement("INSERT INTO resident VALUES (?)");
//	        Statement pstate = con.createStatement();
//	        ResultSet rst = pstate.executeQuery("SELECT RESIDENT_ID FROM resident ORDER BY RESIDENT_ID DESC LIMIT 1");
//
//	        int id = 0;
//	        if (rst.next()) {
//	            String lastId = rst.getString("RESIDENT_ID");
//	            id = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part
//	        }
//
//	        for(NRIResident r:details) {
//				   id++;
//				   r.setResidentId("NRI"+id);
//				   pst.setString(1,r.getResidentId());
//				   pst.executeUpdate();
//			   }
//	       
//	        PreparedStatement insertNRI = con.prepareStatement(
//	            "INSERT INTO nriresident (RESIDENT_ID, RESIDENT_NAME, AGE, GENDER, CONTACT_NUMBER, EMAIL, ADDRESS, " +
//	            "NUMBER_OF_ADULTS, NUMBER_OF_CHILDREN_ABOVE12, NUMBER_OF_CHILDREN_ABOVE5, DURATION_OF_STAY, RESIDENT_TYPE, " +
//	            "PASSPORT_NO, PASSPORT_TYPE, NATIONALITY, PURPOSE_OF_VISIT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
//	        );
//	        Statement stmt = con.createStatement();
//			   ResultSet rs = stmt.executeQuery("SELECT RESIDENT_ID FROM nriresident ORDER BY RESIDENT_ID DESC LIMIT 1");
//			  
//			   int idNum = 0;
//		       if (rs.next()) {
//		           String lastId = rs.getString("RESIDENT_ID"); // e.g. "Booking5"
//		           idNum = Integer.parseInt(lastId.replaceAll("\\D", "")); // extract numeric part (5)
//		        }
//
//	        // Step 3: Insert both records with the same RESIDENT_ID
//	        for (NRIResident r : details) {
//	            idNum++;
//	            r.setResidentId("NRI" + idNum);
//
//	            insertNRI.setString(1, r.getResidentId());
//	            insertNRI.setString(2, r.getResidentName());
//	            insertNRI.setInt(3, r.getAge());
//	            insertNRI.setString(4, r.getGender());
//	            insertNRI.setLong(5, r.getContactNumber());
//	            insertNRI.setString(6, r.getEmail());
//	            insertNRI.setString(7, r.getAddress());
//	            insertNRI.setInt(8, r.getNumberOfAdults());
//	            insertNRI.setInt(9, r.getNumberOfChildrenAbove12());
//	            insertNRI.setInt(10, r.getNumberOfChildrenAbove5());
//	            insertNRI.setInt(11, r.getDurationOfStay());
//	            insertNRI.setString(12, r.getResidentType());
//	            insertNRI.setString(13, r.getPassportNo());
//	            insertNRI.setString(14, r.getPassportType());
//	            insertNRI.setString(15, r.getNationality());
//	            insertNRI.setString(16, r.getPurposeForVisit());
//	            insertNRI.executeUpdate();
//
//	            row++;
//	        }
//
//	        System.out.println(row + " record(s) inserted successfully into nriresident.");
//	    } catch (Exception e) {
//	        e.printStackTrace();
//	    }
//	    return row;
//	}


    // ✅ Method to check if NRIResident ID exists
    public boolean checkIdExists(String nriId) {
        boolean idFound = false;

        try {
          Connection con = DBConnectionManager.establishConnection(); 
             PreparedStatement state = con.prepareStatement("SELECT * FROM nriresident WHERE RESIDENT_ID = ?"); 

            state.setString(1, nriId);
            ResultSet rs = state.executeQuery();
            if (rs.next()) {
                idFound = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return idFound;
    }

    // ✅ Method to fetch NRIResident details for booking
    
    
    public boolean updatePhoneNumberUsingResidentId(String nriId, long newPhone)
    {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET CONTACT_NUMBER = ? WHERE RESIDENT_ID = ?");
            state.setLong(1, newPhone);
            state.setString(2,nriId);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
    }
    
    public boolean updateOccupancyUsingResidentId(String residentId, int adults, int childrenAbove12, int childrenAbove5)
    {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET NUMBER_OF_ADULTS = ?, NUMBER_OF_CHILDREN_ABOVE12 = ?, NUMBER_OF_CHILDREN_ABOVE5 = ? WHERE RESIDENT_ID = ?");
            state.setInt(1, adults);
            state.setInt(2,childrenAbove12);
            state.setInt(3,childrenAbove5);
            state.setString(4, residentId);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
   
    }
    
    public boolean updateNRIResidentPhoneNumberUsingPassportNumber(String passportNo, long newPhone) 
    {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET CONTACT_NUMBER = ? where PASSPORT_NO = ?");
            state.setLong(1, newPhone);
            state.setString(2,passportNo);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
    }
    
    public boolean updateOccupancyUsingPassportNumber(String passportNo, int adults, int childrenAbove12, int childrenAbove5) 
    {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET NUMBER_OF_ADULTS = ?, NUMBER_OF_CHILDREN_ABOVE12 = ?, NUMBER_OF_CHILDREN_ABOVE5 = ? WHERE PASSPORT_NO = ?");
            state.setInt(1, adults);
            state.setInt(2,childrenAbove12);
            state.setInt(3,childrenAbove5);
            state.setString(4, passportNo);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
    }
    
    public boolean updateNRIResidentPhoneNumberUsingContactNumber(long contactNumber, long newPhone) {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET CONTACT_NUMBER = ? CONTACT_NUMBER = ?");
            state.setLong(1, newPhone);
            state.setLong(2,contactNumber);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
    }
    
    public boolean updateOccupancyUsingContactNumber(long contactNumber, int adults, int childrenAbove12, int childrenAbove5) {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("UPDATE nriresident SET NUMBER_OF_ADULTS = ?, NUMBER_OF_CHILDREN_ABOVE12 = ?, NUMBER_OF_CHILDREN_ABOVE5 = ? WHERE CONTACT_NUMBER= ?");
            state.setInt(1, adults);
            state.setInt(2,childrenAbove12);
            state.setInt(3,childrenAbove5);
            state.setLong(4,contactNumber);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;
		
	}
    
    public boolean deleteNRIResidentDetailsFromDB(String residentId)
    {
    	boolean update=false;
    	try {
            Connection con = DBConnectionManager.establishConnection(); 
    	    PreparedStatement state=con.prepareStatement("DELETE FROM nriresident WHERE RESIDENT_ID = ?");
            state.setString(1, residentId);
            int row=state.executeUpdate();
			  if(row>0)
				  update=true;
			  else
				  update=false;
    }
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    	return update;

    }
   
      
  public List<NRIResident> retrieveNRIResidentDetailsForBooking(String nriId) {
	  List<NRIResident> nriResident =new ArrayList<>();

      try{
    	  Connection con = DBConnectionManager.establishConnection();
    	  PreparedStatement state = con.prepareStatement("SELECT * FROM nriresident WHERE RESIDENT_ID = ?");

          state.setString(1, nriId);
          ResultSet rs = state.executeQuery();

          while(rs.next()) {
        	  
              String id = rs.getString("RESIDENT_ID");
              String name = rs.getString("RESIDENT_NAME");
              int age = rs.getInt("AGE");
              String gender = rs.getString("GENDER");
              long num = rs.getLong("CONTACT_NUMBER");
              String mail = rs.getString("EMAIL");
              String address = rs.getString("ADDRESS");
              int noOfAdults = rs.getInt("NUMBER_OF_ADULTS");
              int noOfChildAbove12 = rs.getInt("NUMBER_OF_CHILDREN_ABOVE12");
              int noOfChildAbove5 = rs.getInt("NUMBER_OF_CHILDREN_ABOVE5");
              int duration = rs.getInt("DURATION_OF_STAY");
              String type = rs.getString("RESIDENT_TYPE");
              String passNo = rs.getString("PASSPORT_NO");
              String passType = rs.getString("PASSPORT_TYPE");
              String nationality = rs.getString("NATIONALITY");
              String purpose = rs.getString("PURPOSE_OF_VISIT");

              NRIResident nri= new NRIResident(id, name, age, gender, num, mail, address, noOfAdults,
                      noOfChildAbove12, noOfChildAbove5, duration, type, passNo, passType, nationality, purpose);
              nriResident.add(nri);
          }

      } catch (Exception e) {
          e.printStackTrace();
      }

      return nriResident;
  }

	
}