package com.management;
import java.sql.*;
import java.sql.Date;
import java.util.*;
import com.model.Payment;

public class PaymentManagement {

    public boolean checkIdExists(String paymentId) {
        boolean exists = false;
        try (Connection con = DBConnectionManager.establishConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT PAYMENT_ID FROM payment WHERE PAYMENT_ID = ?");
            ps.setString(1, paymentId);
            ResultSet rs = ps.executeQuery();
            exists = rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return exists;
    }

    public boolean insertPaymentList(List<Payment> pay) {
        boolean flag=false;
        try (Connection con = DBConnectionManager.establishConnection()) {
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO payment VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            for(Payment p:pay) {
            ps.setString(1, p.getPaymentId());
            ps.setString(2, p.getBookingId());
            ps.setString(3, p.getResidentName());
            ps.setString(4, p.getFloorNumber());
            ps.setString(5, p.getRoomNumber());
            ps.setDate(6, new java.sql.Date(p.getCheckInDate().getTime()));
            ps.setDate(7, new java.sql.Date(p.getCheckOutDate().getTime()));
            ps.setDate(8, new java.sql.Date(p.getPaymentDate().getTime()));
            ps.setString(9, p.getPaymentMethod());
            ps.setDouble(10, p.getBillAmount());
            int row = ps.executeUpdate();
            if(row>0)
            	flag=true;
            else
            	flag=false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<Payment> viewPaymentDetails(String paymentId) {
    	List<Payment> pay = new ArrayList<>();
        try (Connection con = DBConnectionManager.establishConnection()) {
            PreparedStatement ps = con.prepareStatement("SELECT * FROM payment WHERE PAYMENT_ID = ?");
            ps.setString(1, paymentId);
            ResultSet rs = ps.executeQuery();
            while(rs.next()) {
                
                String id=rs.getString(1);
                String bid=rs.getString(2);
                String name=rs.getString(3);
                String FloorNumber=rs.getString(4);
                String RoomNumber=rs.getString(5);
                Date CheckInDate=rs.getDate(6);
                Date CheckOutDate=rs.getDate(7);
                Date PaymentDate=rs.getDate(8);
                String PaymentMethod=rs.getString(9);
                double BillAmount=rs.getDouble(10);
                
                Payment p=new Payment(id,bid,name,FloorNumber,RoomNumber,CheckInDate,CheckOutDate,PaymentDate,PaymentMethod,BillAmount);
                pay.add(p);
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return pay;
    }
    
}
