package java.com;

public class management {

}
